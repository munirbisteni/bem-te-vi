package com.example.tubarao_tigre

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
