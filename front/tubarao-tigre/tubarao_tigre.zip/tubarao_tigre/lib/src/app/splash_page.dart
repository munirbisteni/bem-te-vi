import 'package:flutter/material.dart';
import 'package:tubarao_tigre/api/models/account_model.dart';
import 'package:tubarao_tigre/api/repositories/account_repository.dart';
import 'package:tubarao_tigre/api/services/shared_local_storage_service.dart';
import 'package:tubarao_tigre/api/views/account_view.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  SplashPageState createState() => SplashPageState();
}

class SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    AccountView userRepository = AccountView(AccountRepository());

    AccountModel? profile = await SharedLocalStorageService().getProfile();
    int? id = profile?.id;

    // bool isLogged = await userRepository.repository
    //     .checkToken()
    //     .timeout(const Duration(seconds: 5), onTimeout: () => false);

    // bool isFirstSession =
    //     await userRepository.repository.doesUserHaveProduct(id);

  //   Future.delayed(const Duration(seconds: 2), () async {
  //     if (isLogged) {
  //       if (isFirstSession) {
  //         Navigator.pushReplacement(
  //           context,
  //           MaterialPageRoute(
  //             builder: (context) => const FirstSessionPage(),
  //           ),
  //         );
  //       } else {
  //         Navigator.pushReplacement(
  //           context,
  //           MaterialPageRoute(
  //             builder: (context) => const Homepage(),
  //           ),
  //         );
  //       }
  //     } else {
  //       Navigator.pushReplacement(
  //         context,
  //         MaterialPageRoute(
  //           builder: (context) => const LoginPage(),
  //         ),
  //       );
  //     }
  //   });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}