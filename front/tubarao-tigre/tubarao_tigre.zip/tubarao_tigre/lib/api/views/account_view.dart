

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tubarao_tigre/api/models/account_model.dart';
import 'package:tubarao_tigre/api/repositories/account_repository.dart';
import 'package:tubarao_tigre/api/services/shared_local_storage_service.dart';

class AccountView extends ValueNotifier<AccountModel>{
  final AccountRepository repository;

  AccountView(this.repository) : super(AccountModel());

  final accountModel = ValueNotifier<AccountModel>(AccountModel());
  
  loadAccountCredentials(String email, String password) async{
    accountModel.value = await repository.login(email, password);
  }

  registerUser(String email, String firstName, String lastName, String password) async{
    accountModel.value = await repository.register(email, firstName, lastName, password);
  }

  logout() async {
    SharedLocalStorageService().delete('token');
    accountModel.value = AccountModel();
  }
}