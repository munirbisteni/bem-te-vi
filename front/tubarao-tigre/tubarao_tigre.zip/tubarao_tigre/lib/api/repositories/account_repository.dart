import 'dart:js_interop_unsafe';

import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:tubarao_tigre/api/interfaces/account_interface.dart';
import 'package:tubarao_tigre/api/models/account_model.dart';
import 'package:tubarao_tigre/api/services/http_client.dart';
import 'package:tubarao_tigre/api/services/shared_local_storage_service.dart';

class AccountRepository implements IAccount{
  late HttpClient networkClient;
  
  AccountRepository(){
    networkClient = HttpClient();
  }
  
  @override 
  Future<AccountModel> login(String email, String password) async {
    var response =  await networkClient.client.post('/account/login', data:
      {
        'email': email,
        'password': password  
      }
    );
    logout();

    AccountModel model = AccountModel.fromJson(response.data['account']);
    SharedLocalStorageService().put('token', response.data['token']);
    SharedLocalStorageService().putProfile(model);
    return model;
  }

  logout(){
    SharedLocalStorageService().delete('token');
    SharedLocalStorageService().clearProfile();
  }

  @override 
  Future<AccountModel> register(String email, String firstName, String lastName, String password) async {
    var response =  await networkClient.client.post('/account/login', data:
      {
        'email': email,
        'firstName': firstName,
        'lastName': lastName,
        'password': password 
      }
    );
    logout();

    AccountModel model = AccountModel.fromJson(response.data['account']);
    SharedLocalStorageService().put('token', response.data['token']);
    SharedLocalStorageService().putProfile(model);
    return model;
  }  
}