import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class HttpClient{
  late Dio client;
  HttpClient(){
    client = Dio(BaseOptions(
      baseUrl: dotenv.env['BASE_URL'] ?? 'http://localhost/8080',
      headers: {
        'Content-Type' : 'application/json'
      },
    ));
  }
}
