

import 'package:tubarao_tigre/api/models/account_model.dart';

abstract class IAccount {
  Future<AccountModel> login(String email, String password);
  Future<AccountModel> register(String email, String firstName, String lastName, String password);
}